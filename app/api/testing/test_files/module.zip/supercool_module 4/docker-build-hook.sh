#!/usr/bin/env sh

echo "hey :)"

# install nmap
#apk add nmap
